from django.db import models

# Create your models here.

class Member(models.Model):
  firstname = models.CharField(max_length=255)
  Applying_profit_Loss_strategy = models.CharField(max_length=255)
  Current_Price = models.IntegerField(null=True)
  Profit_loss_for_last_1_years = models.IntegerField(null=True)
  Thershold_percent = models.IntegerField(null=True)
  Fiftytwo_week_high = models.IntegerField(null=True)
  Market_cap = models.IntegerField(null=True)
  Image_field = models.ImageField(null=True)

  def __str__(self):
    return f"{self.firstname}"